package com.cg.mobilebilling.services;	
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.daoservices.BillingDAOServices;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;

@Service
@Transactional
public class BillingServicesImpl implements BillingServices {

	@Autowired
	BillingDAOServices dao;
	
	@Override
	public List<Plan> getPlanAllDetails() throws BillingServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long openPostpaidMobileAccount(int customerID, int planId,PostpaidAccount account)
			throws PlanDetailsNotFoundException,
			CustomerDetailsNotFoundException, BillingServicesDownException {
		Plan plan=new Plan();
		plan.setPlanID(planId);
		if(planId==199){
			plan.setFreeInternetDataUsageUnits(250);
			plan.setFreeLocalCalls(100);
			plan.setFreeLocalSMS(50);
			plan.setFreeStdCalls(400);
			plan.setFreeStdSMS(50);
			plan.setInternetDataUsageRate(2.5f);
			plan.setLocalCallRate(0.2f);
			plan.setLocalSMSRate(1);
			plan.setMonthlyRental(199);
			plan.setPlanCircle("Delhi");
			plan.setPlanName("199 Dhamakedar Blockbuster Plan");
			plan.setStdCallRate(6.5f);
			plan.setStdSMSRate(1.5f);
		}
		else if(planId==299)
		{
			plan.setFreeInternetDataUsageUnits(500);
			plan.setFreeLocalCalls(400);
			plan.setFreeLocalSMS(100);
			plan.setFreeStdCalls(800);
			plan.setFreeStdSMS(100);
			plan.setInternetDataUsageRate(2.5f);
			plan.setLocalCallRate(0.2f);
			plan.setLocalSMSRate(1);
			plan.setMonthlyRental(299);
			plan.setPlanCircle("Delhi");
			plan.setPlanName("299 Silver Jublee Plan");
			plan.setStdCallRate(6.5f);
			plan.setStdSMSRate(1.5f);
		}
		else if(planId==499)
		{
			plan.setFreeInternetDataUsageUnits(1024);
			plan.setFreeLocalCalls(500);
			plan.setFreeLocalSMS(100);
			plan.setFreeStdCalls(800);
			plan.setFreeStdSMS(100);
			plan.setInternetDataUsageRate(2.5f);
			plan.setLocalCallRate(0.2f);
			plan.setLocalSMSRate(1);
			plan.setMonthlyRental(499);
			plan.setPlanCircle("Delhi");
			plan.setPlanName("499 Sishandi Plan");
			plan.setStdCallRate(6.5f);
			plan.setStdSMSRate(1.5f);
		}
		account.setPlan(plan);
		return dao.insertPostPaidAccount(customerID, account);
	}

	@Override
	public double generateMonthlyMobileBill(int customerID, long mobileNo,
			String billMonth, int noOfLocalSMS, int noOfStdSMS,
			int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits, int planId)
			throws CustomerDetailsNotFoundException,
			PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillingServicesDownException, PlanDetailsNotFoundException {
		// TODO Auto-generated method stub
		
		PostpaidAccount p= dao.getPlanDetails(customerID, mobileNo);
		int BillednoOfLocalSMS = (noOfLocalSMS-p.getPlan().getFreeLocalSMS());
		int BillednoOfStdSMS = (noOfStdSMS-p.getPlan().getFreeStdSMS());
		int BillednoOfLocalCalls = (noOfLocalCalls-p.getPlan().getFreeLocalCalls());
		int BillednoOfStdCalls = (noOfStdCalls-p.getPlan().getFreeStdCalls());
		int BilledinternetDataUsageUnits = (internetDataUsageUnits-p.getPlan().getFreeInternetDataUsageUnits());
		
		float localCallAmount= BillednoOfLocalCalls*p.getPlan().getLocalCallRate();
		float StdCallAmount = BillednoOfStdCalls*p.getPlan().getStdCallRate();
		float LocalSMSAmount= BillednoOfLocalSMS*p.getPlan().getLocalSMSRate();
		float StdSMSAmount = BillednoOfStdSMS*p.getPlan().getStdSMSRate();
		float internetAmount = BilledinternetDataUsageUnits*p.getPlan().getInternetDataUsageRate();
		
		float vat=  0.08f;
		float serviceTax= 0.15f;
		float Amount= localCallAmount+StdCallAmount+LocalSMSAmount+StdSMSAmount+internetAmount; 
		float VatAmount=  Amount*vat;
		float serviceTaxAmount = serviceTax*Amount;
		
		float TotalBillAmount= Amount+VatAmount+serviceTaxAmount;
		
		Bill bill =new Bill(noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits,billMonth,TotalBillAmount,LocalSMSAmount, StdSMSAmount, localCallAmount, StdCallAmount,internetAmount, serviceTaxAmount, VatAmount );
		
		
		return dao.insertMonthlybill(customerID, mobileNo, bill);
	}

	@Override
	public Customer getCustomerDetails(int customerID)
			throws CustomerDetailsNotFoundException,
			BillingServicesDownException {
		// TODO Auto-generated method stub
		return dao.getCustomer(customerID);
	}

	@Override
	public List<Customer> getAllCustomerDetails()
			throws BillingServicesDownException {
		// TODO Auto-generated method stub
		return dao.getAllCustomers();
	}

	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID,
			long mobileNo) throws CustomerDetailsNotFoundException,
			PostpaidAccountNotFoundException, BillingServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(
			int customerID) throws CustomerDetailsNotFoundException,
			BillingServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo,
			String billMonth) throws CustomerDetailsNotFoundException,
			PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException, BillingServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID,
			long mobileNo) throws CustomerDetailsNotFoundException,
			PostpaidAccountNotFoundException, BillingServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID)
			throws CustomerDetailsNotFoundException,
			PostpaidAccountNotFoundException, PlanDetailsNotFoundException,
			BillingServicesDownException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException,
			PostpaidAccountNotFoundException, BillingServicesDownException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerID)
			throws BillingServicesDownException,
			CustomerDetailsNotFoundException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public PostpaidAccount getCustomerPostPaidAccountPlanDetails(int customerID,
			long mobileNo) throws CustomerDetailsNotFoundException,
			PostpaidAccountNotFoundException, BillingServicesDownException,
			PlanDetailsNotFoundException {
		// TODO Auto-generated method stub
		return dao.getPlanDetails(customerID, mobileNo);
	}

	@Override
	public Customer acceptCustomerDetails(Customer customer)
			throws BillingServicesDownException {
		// TODO Auto-generated method stub
		return dao.insertCustomer(customer);
	}

	@Override
	public boolean authenticateCustomer(Customer customer)
			throws CustomerDetailsNotFoundException,
			BillingServicesDownException {
		// TODO Auto-generated method stub
		return false;
	}


}
